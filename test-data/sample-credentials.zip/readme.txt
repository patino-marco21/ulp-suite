# readme.txt
#
# This entry intentionally contains no parseable credentials — every line is
# a comment or section header. It exercises the "skipped" / blank rejection
# path when a ZIP archive bundles a non-credential file alongside real combo
# lists, which is common in ULP archives shared on breach forums.

[notes]
// nothing to see here
